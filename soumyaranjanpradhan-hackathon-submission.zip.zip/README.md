
# Configurable Workflow Decision Platform

This project implements a simple configurable workflow decision system.

## Features
- Rule-based decision engine
- Multi-stage workflow processing
- REST API using Flask
- Audit logging
- Idempotent request handling

## Run the Project

Install dependencies:

pip install -r requirements.txt

Run:

python decision_platform.py

Server runs at:

http://127.0.0.1:5000

## Example Request

POST /evaluate

{
 "request_id": "101",
 "age": 25,
 "income": 50000,
 "credit_score": 720
}
