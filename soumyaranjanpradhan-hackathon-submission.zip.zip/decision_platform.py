
# ==========================================
# CONFIGURABLE WORKFLOW DECISION PLATFORM
# Single-file hackathon implementation
# Author: Soumya Ranjan Pradhan
# ==========================================

from flask import Flask, request, jsonify
from datetime import datetime
import uuid

app = Flask(__name__)

# --------------------------------------------------
# CONFIGURABLE RULES
# --------------------------------------------------

workflow_config = {
    "stages": [
        {
            "name": "validation",
            "rules": [
                {"field": "age", "operator": ">=", "value": 18},
                {"field": "income", "operator": ">", "value": 30000}
            ]
        },
        {
            "name": "risk_assessment",
            "rules": [
                {"field": "credit_score", "operator": ">", "value": 700}
            ]
        }
    ]
}

processed_requests = {}
audit_logs = []

def evaluate_rule(data, rule):
    field = rule["field"]
    operator = rule["operator"]
    value = rule["value"]

    if field not in data:
        return False

    if operator == ">":
        return data[field] > value
    elif operator == "<":
        return data[field] < value
    elif operator == ">=":
        return data[field] >= value
    elif operator == "<=":
        return data[field] <= value
    elif operator == "==":
        return data[field] == value

    return False

def log_audit(entry):
    entry["timestamp"] = str(datetime.now())
    audit_logs.append(entry)

def process_request(data):
    request_id = data.get("request_id")

    if not request_id:
        request_id = str(uuid.uuid4())
        data["request_id"] = request_id

    if request_id in processed_requests:
        return processed_requests[request_id]

    for stage in workflow_config["stages"]:
        for rule in stage["rules"]:

            result = evaluate_rule(data, rule)

            log_audit({
                "request_id": request_id,
                "stage": stage["name"],
                "rule": rule,
                "result": result
            })

            if not result:
                decision = {
                    "request_id": request_id,
                    "decision": "REJECTED",
                    "failed_stage": stage["name"]
                }

                processed_requests[request_id] = decision
                return decision

    decision = {
        "request_id": request_id,
        "decision": "APPROVED",
        "stage": "final_approval"
    }

    processed_requests[request_id] = decision
    return decision

@app.route("/")
def home():
    return {"message": "Workflow Decision Platform Running"}

@app.route("/evaluate", methods=["POST"])
def evaluate():
    data = request.json
    result = process_request(data)
    return jsonify(result)

@app.route("/audit/<request_id>")
def audit(request_id):
    logs = [log for log in audit_logs if log["request_id"] == request_id]
    return jsonify(logs)

if __name__ == "__main__":
    app.run(debug=True)
